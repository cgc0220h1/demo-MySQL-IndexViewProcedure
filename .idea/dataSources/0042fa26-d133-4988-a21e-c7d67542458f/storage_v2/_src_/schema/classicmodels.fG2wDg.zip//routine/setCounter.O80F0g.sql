create
    definer = root@localhost procedure setCounter(IN inc int, INOUT counter int)
BEGIN
    SET counter = counter + inc;
END;

