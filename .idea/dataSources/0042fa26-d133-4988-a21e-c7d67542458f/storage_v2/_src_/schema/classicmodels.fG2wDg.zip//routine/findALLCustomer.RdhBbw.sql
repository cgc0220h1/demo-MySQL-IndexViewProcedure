create
    definer = root@localhost procedure findALLCustomer()
BEGIN
    SELECT * FROM classicmodels.customers WHERE customerNumber = 175;
END;

