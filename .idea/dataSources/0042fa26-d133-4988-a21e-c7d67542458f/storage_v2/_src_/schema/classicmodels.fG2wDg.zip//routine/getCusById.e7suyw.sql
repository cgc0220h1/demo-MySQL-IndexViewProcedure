create
    definer = root@localhost procedure getCusById(IN cusNUm int)
BEGIN
    SELECT * FROM customers WHERE  customerNumber = cusNUm;
END;

