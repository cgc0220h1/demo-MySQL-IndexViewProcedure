create
    definer = root@localhost procedure getCustomersCountByCity(IN in_city varchar(10), OUT total int)
BEGIN
    SELECT COUNT(customerNumber)
        INTO total
    FROM customers
        WHERE city = in_city;
END;

