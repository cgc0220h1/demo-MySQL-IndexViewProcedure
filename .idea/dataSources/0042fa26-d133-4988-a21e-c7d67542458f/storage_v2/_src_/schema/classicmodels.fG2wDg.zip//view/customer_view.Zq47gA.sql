create definer = root@localhost view customer_view as
select `classicmodels`.`customers`.`customerName` AS `customerName`,
       `classicmodels`.`customers`.`addressLine1` AS `addressLine1`
from `classicmodels`.`customers`;

