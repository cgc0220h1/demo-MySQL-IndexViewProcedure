create
    definer = root@localhost procedure checkValue(IN value1 int, OUT value2 int)
BEGIN
    set value2 = (select Amount from sumofall where Amount = value1);
end;

